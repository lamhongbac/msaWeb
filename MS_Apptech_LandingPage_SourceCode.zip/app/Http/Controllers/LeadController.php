<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Lead;
use Illuminate\Support\Facades\Http; // Dùng để gọi API Zalo

class LeadController extends Controller
{
    // Hàm lưu dữ liệu từ Landing Page
    public function store(Request $request)
    {
        $request->validate([
            'fullname' => 'required|string|max:255',
            'phone'    => 'required|string|max:20',
            'company'  => 'required|string|max:255',
        ]);

        $lead = Lead::create($request->all());

        // GỌI HÀM GỬI ZALO Ở ĐÂY
        $this->sendZaloNotification($lead);

        return back()->with('success', 'Cảm ơn Anh/Chị! Yêu cầu tư vấn đã được ghi nhận.');
    }

    // Hàm hiển thị trang Admin
    public function index()
    {
        // Lấy danh sách khách hàng, sắp xếp mới nhất lên đầu
        $leads = Lead::orderBy('created_at', 'desc')->get();
        return view('admin', compact('leads'));
    }

    // Hàm đánh dấu đã đọc
    public function markAsRead($id)
    {
        $lead = Lead::findOrFail($id);
        $lead->update(['is_read' => true]);
        return back()->with('success', 'Đã đánh dấu đọc tin nhắn của ' . $lead->fullname);
    }

    // 4. Hàm giao tiếp với Zalo API
    private function sendZaloNotification1($lead)
    {
        $accessToken = 'AXyLI91hD00l7Hb0bMu_0ouH4akNUJHvAWyHQS0BQa8lEnbSmr0yH39P647jM5f47cyPK_LWFdOiRdXVod8LNmTMSdVuKIbG1IDqQUieAcijDrHEd2C24Yq8KrRf83Tk6ZbCRTH8QMG8MqGcjrDfEGzl4nlhM4qlMaGFAePoTIf4HmvleqPEPsyn7rgv83nFUnL9MQKoQbvPDIeVlmDS0rS3FKMT77rS8ZTGMVaGQHiHC1edgHbO8Mad626O4KTdMWWWIQeX3Mf23tn9_X41QYPX8ohB5WKiSZjE1uWJ85ja0b59WJu90JurVm3G55qmC3O_08y1PYDE5rymdZqgUIOwHZxV91mjDm5dDOeTHJHmD3PqOOb6576NTp8B';
        $adminUserId = '7223050807139948731';

        $message = "🎉 KHÁCH HÀNG MỚI ĐĂNG KÝ TƯ VẤN AI:\n"
                 . "👤 Tên: {$lead->fullname}\n"
                 . "📱 SĐT: {$lead->phone}\n"
                 . "🏢 Đơn vị: {$lead->company}\n"
                 . "🏷️ Dịch vụ: " . ($lead->category ?? 'Không rõ') . "\n"
                 . "❓ Vấn đề: {$lead->problem}";

        try {
            Http::withHeaders([
                'access_token' => $accessToken,
                'Content-Type' => 'application/json'
            ])->post('https://openapi.zalo.me/v3.0/oa/message/cs', [
                'recipient' => ['user_id' => $adminUserId],
                'message'   => ['text' => $message]
            ]);
        } catch (\Exception $e) {
            \Log::error('Zalo API Error: ' . $e->getMessage());
        }
    }
    private function sendZaloNotification($lead)
    {
        try {
            $accessToken = 'GNnsAeOuQqT4VtCeWpTiIa5mS2M8BZ88EoSbAB8ZE1CiOauyjtK2DIj86YsjNL8wDqW8AgzpIGTjSJ9mmsL8PcjAF6pl2M1WUo05KQSIG6KFAHnFY0vgOZWaV4w3Csjm9tCYQwn4VKWh3MDGkGazHduNVNwtBZv2AXT2SkmF9Heh9c8vZYKY24ewM3ZK3GTKLIfFOzqJ2rvS6XTYx0Xx2K8f3GBdCKW7BdWa3RHvK00QH10Jl0n837eHBZx5648eG0u59CGsT2qCBGXEaYzMKKuo0N_GUabs4tiIHP9o3NKcM4rf-aqM2sbvJHtJF2uKQIz89CqyCJPkUtSfhZvi81O13Y-YGqD32riAHgfZSru1VHeqjL9j3oD36HE2Hd0X6tzj0gXxDpPfONHOt7a_SKP4OafnR_5mBbg48cj9';
            
            $jsonPath = base_path('zalo_receivers.json');
            $receivers = ['7223050807139948731']; // Default if file not found
            
            if (file_exists($jsonPath)) {
                $jsonData = json_decode(file_get_contents($jsonPath), true);
                if (isset($jsonData['receivers']) && is_array($jsonData['receivers'])) {
                    $receivers = $jsonData['receivers'];
                }
            }

            $message = "🎉 KHÁCH HÀNG MỚI ĐĂNG KÝ TƯ VẤN AI:\n"
                     . "👤 Tên: {$lead->fullname}\n"
                     . "📱 SĐT: {$lead->phone}\n"
                     . "🏢 Đơn vị: {$lead->company}\n"
                     . "🏷️ Dịch vụ: " . ($lead->category ?? 'Không rõ') . "\n"
                     . "❓ Vấn đề: {$lead->problem}";

            foreach ($receivers as $userId) {
                $response = Http::withHeaders([
                    'access_token' => $accessToken,
                    'Content-Type' => 'application/json'
                ])->post('https://openapi.zalo.me/v3.0/oa/message/cs', [
                    'recipient' => ['user_id' => $userId],
                    'message'   => ['text' => $message]
                ]);

                if ($response->failed()) {
                    \Log::error('Zalo API Request Failed for user ' . $userId, ['response' => $response->json()]);
                } else {
                    \Log::info('Zalo API Success for user ' . $userId, ['response' => $response->json()]);
                }
            }
        } catch (\Exception $e) {
            \Log::error('Zalo API Error: ' . $e->getMessage(), [
                'lead_id' => $lead->id ?? null,
                'trace' => $e->getTraceAsString()
            ]);
        }
    }
}
