<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản trị Khách hàng - MS-Apptech</title>
    <style>
        body { font-family: system-ui, sans-serif; background: #f4f8f9; padding: 20px; color: #112a2d; }
        .container { max-width: 1200px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 30px rgba(17,42,45,0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #d2dedf; }
        th { background: #368187; color: white; }
        .unread { background: #fff3cd; font-weight: bold; } /* Làm nổi bật tin chưa đọc */
        .btn-read { background: #e97f32; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; }
        .btn-read:hover { background: #cf681f; }
        .status-read { color: #8fa0a3; font-size: 13px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Danh sách Khách hàng Đăng ký Tư vấn AI F&B</h2>

        @if(session('success'))
            <p style="color: green; font-weight: bold;">{{ session('success') }}</p>
        @endif

        <table>
            <thead>
                <tr>
                    <th>Ngày đăng ký</th>
                    <th>Họ và Tên</th>
                    <th>Số điện thoại</th>
                    <th>Đơn vị / Nhà hàng</th>
                    <th>Dịch vụ quan tâm</th>
                    <th>Bài toán cần giải quyết</th>
                    <th>Trạng thái</th>
                </tr>
            </thead>
            <tbody>
                @foreach($leads as $lead)
                <tr class="{{ $lead->is_read ? '' : 'unread' }}">
                    <td>{{ $margin = $lead->created_at->format('d/m/Y H:i') }}</td>
                    <td>{{ $lead->fullname }}</td>
                    <td>{{ $lead->phone }}</td>
                    <td>{{ $lead->company }}</td>
                    <td>{{ $lead->category }}</td>
                    <td>{{ $lead->problem }}</td>
                    <td>
                        @if($lead->is_read)
                            <span class="status-read">✓ Đã xử lý</span>
                        @else
                            <form action="/admin/leads/{{ $lead->id }}/read" method="POST">
                                @csrf
                                <button type="submit" class="btn-read">Đánh dấu đã đọc</button>
                            </form>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>
</html>

