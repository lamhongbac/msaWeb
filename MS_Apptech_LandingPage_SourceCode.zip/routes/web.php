<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LeadController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/course/fnb', function () {
    return view('course.fnb');
})->name('course.fnb');

// Route xử lý form đăng ký
Route::post('/submit-form', [LeadController::class, 'store']);
// Các Route dành cho Admin
Route::get('/admin/leads', [LeadController::class, 'index']);
Route::post('/admin/leads/{id}/read', [LeadController::class, 'markAsRead']);
